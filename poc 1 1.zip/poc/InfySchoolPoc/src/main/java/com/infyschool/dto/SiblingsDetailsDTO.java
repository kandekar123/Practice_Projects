package com.infyschool.dto;

public class SiblingsDetailsDTO {
	
	private String name;
	private Float age;
	private String type;
	private String job;
	
	
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getAge() {
		return age;
	}
	public void setAge(Float age) {
		this.age = age;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "SiblingsDetailsDTO [name=" + name + ", age=" + age + ", type=" + type + ", job=" + job + "]";
	}
	

}
