package com.infyschool.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class Science {
	@Min(value = 0,message = "Written  marks should be greater than or equal to 0")
	@Max(value= 100,message = "Written marks should be less than or equal to 100")
	@NotNull(message = "written.marks.must")
	private float written;
	@Min(value = 0,message = "Viva  marks should be greater than or equal to 0")
	@Max(value= 25,message = "Viva marks should be less than or equal to 25")
	@NotNull(message = "viva.marks.must")
	private float viva;
	@Min(value = 0,message = "Assignment  marks should be greater than or equal to 0")
	@Max(value= 25,message = "Assignment marks should be less than or equal to 25")
	@NotNull(message = "assignment.marks.must")
	private float assignment;
	
	
	
	public Science(
			@Min(value = 0, message = "Written  marks should be greater than or equal to 0") @Max(value = 100, message = "Written marks should be less than or equal to 100") @NotNull(message = "written.marks.must") float written,
			@Min(value = 0, message = "Viva  marks should be greater than or equal to 0") @Max(value = 25, message = "Viva marks should be less than or equal to 25") @NotNull(message = "viva.marks.must") float viva,
			@Min(value = 0, message = "Assignment  marks should be greater than or equal to 0") @Max(value = 25, message = "Assignment marks should be less than or equal to 25") @NotNull(message = "assignment.marks.must") float assignment) {
		super();
		this.written = written;
		this.viva = viva;
		this.assignment = assignment;
	}

	
	public Science() {
		// TODO Auto-generated constructor stub
	}


	public float getWritten() {
		return written;
	}

	public void setWritten(float written) {
		this.written = written;
	}

	public float getViva() {
		return viva;
	}

	public void setViva(float viva) {
		this.viva = viva;
	}

	public float getAssignment() {
		return assignment;
	}

	public void setAssignment(float assignment) {
		this.assignment = assignment;
	}

	@Override
	public String toString() {
		return "Science [written=" + written + ", viva=" + viva + ", assignment=" + assignment + "]";
	}

}
