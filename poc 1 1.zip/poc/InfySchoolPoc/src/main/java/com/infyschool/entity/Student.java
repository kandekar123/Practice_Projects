package com.infyschool.entity;

import javax.persistence.Column;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

@Entity
@Table(name = "tabln")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Student {

	@Id
	@Column(name = "student_id")
	private Long studentId;

	@NotEmpty(message = "{student.studentName.must}")
//	@Pattern(regexp = "^(?=.*[a-zA-Z]).{3,}$")
	@Column(name = "student_name")
	private String studentName;

	@NotNull(message = "{student.studentAdmissionYear.must}")
	@Min(value = 2000, message = "{student.studentAdmissionYear.Minlimit}")
	@Max(value = 2020, message = "{student.studentAdmissionYear.Maxlimit}")
	@Column(name = "admission_year")
	private int admissionYear;

	@Valid
	@Column(name = "student_data")
	@Type(type = "jsonb")
	private StudentData studentData;

	@Column(name = "iq_score")
//	@Min(value = 0, message = "Score must be between 0 and 100")kalayanam
//	@Max(value = 100, message = "Score must be between 0 and 100")kalayanam
//	@NotEmpty(message="{student.studentiQScore.must}") ithu venda
	private Integer iqScore;

//	@NotEmpty(message="{student.noOfAttempts.must}")
	@Column(name = "no_of_attempts")
	private int noOfAttempts;

	public Student() {
		super();
	}

	public Student(Long studentId, String studentName, int admissionYear, StudentData studentData, Integer iqScore,
			int noOfAttempts) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.admissionYear = admissionYear;
		this.studentData = studentData;
		this.iqScore = iqScore;
		this.noOfAttempts = noOfAttempts;

	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getAdmissionYear() {
		return admissionYear;
	}

	public void setAdmissionYear(int admissionYear) {
		this.admissionYear = admissionYear;
	}

	public StudentData getStudentData() {
		return studentData;
	}

	public void setStudentData(StudentData studentData) {
		this.studentData = studentData;
	}

	public Integer getIqScore() {
		return iqScore;
	}

	public void setIqScore(Integer iqScore) {
		this.iqScore = iqScore;
	}

	public Integer getNoOfAttempts() {
		return noOfAttempts;
	}

	public void setNoOfAttempts(Integer noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	@Override
	public String toString() {

		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", admissionYear=" + admissionYear
				+ ", studentData=" + studentData + ", iqScore=" + iqScore + ", noOfAttempts=" + noOfAttempts + "]";
	}
}
