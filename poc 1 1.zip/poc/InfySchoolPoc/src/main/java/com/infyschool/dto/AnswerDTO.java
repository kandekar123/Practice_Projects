package com.infyschool.dto;

public class AnswerDTO {
	public Integer qn;

	public char ans;

	public AnswerDTO(Integer qn, char ans) {
		super();
		this.qn = qn;
		this.ans = ans;
	}

	public Integer getQn() {
		return qn;
	}

	public void setQn(Integer qn) {
		this.qn = qn;
	}

	public char getAns() {
		return ans;
	}

	public void setAns(char ans) {
		this.ans = ans;
	}

	@Override
	public String toString() {
		return "Answer [qn=" + qn + ", ans=" + ans + "]";
	}
}
