package com.infyschool.entity;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class Grade {
	@Valid
	@NotNull(message = "{grade.mathemathics.must}")
	private Mathematics mathematics;
	@Valid
	@NotNull(message = "{grade.science.must}")
	private Science science;
	@Valid
	@NotNull(message = "{grade.socialscience.must}")
	private Socialscience socialscience;
	@Valid
	@NotNull(message = "{grade.english.must}")
	private English english;
	@Valid
	@NotNull(message = "{grade.malayalam.must}")
	private Malayalam malayalam;
	
	
	
	public Grade(@Valid @NotNull(message = "{grade.mathemathics.must}") Mathematics mathematics,
			@Valid @NotNull(message = "{grade.science.must}") Science science,
			@Valid @NotNull(message = "{grade.socialscience.must}") Socialscience socialscience,
			@Valid @NotNull(message = "{grade.english.must}") English english,
			@Valid @NotNull(message = "{grade.malayalam.must}") Malayalam malayalam) {
		super();
		this.mathematics = mathematics;
		this.science = science;
		this.socialscience = socialscience;
		this.english = english;
		this.malayalam = malayalam;
	}
	

	public Grade() {
		// TODO Auto-generated constructor stub
	}


	public Mathematics getMathematics() {
		return mathematics;
	}

	public void setMathematics(Mathematics mathematics) {
		this.mathematics = mathematics;
	}

	public Science getScience() {
		return science;
	}

	public void setScience(Science science) {
		this.science = science;
	}

	public Socialscience getSocialscience() {
		return socialscience;
	}

	public void setSocialscience(Socialscience socialscience) {
		this.socialscience = socialscience;
	}

	public English getEnglish() {
		return english;
	}

	public void setEnglish(English english) {
		this.english = english;
	}

	public Malayalam getMalayalam() {
		return malayalam;
	}

	public void setMalayalam(Malayalam malayalam) {
		this.malayalam = malayalam;
	}

	@Override
	public String toString() {
		return "Grade [mathematics=" + mathematics + ", science=" + science + ", socialscience=" + socialscience
				+ ", english=" + english + ", malayalam=" + malayalam + "]";
	}

}
