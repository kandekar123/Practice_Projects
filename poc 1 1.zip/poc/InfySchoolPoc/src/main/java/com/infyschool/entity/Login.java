package com.infyschool.entity;

import java.time.LocalDate;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

@Entity
@Table(name = "logintable")
public class Login {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "id_seq7")
	@SequenceGenerator(name = "id_seq7", sequenceName = "id_seq7", initialValue = 1, allocationSize = 1)
	@Column(name = "student_id")
	private Long loginid;

	@NotEmpty(message = "{login.username.must}")
//	@Pattern(regexp="^(?=.*[a-zA-Z]).{3,16}$",message= "{customer.username.invalid}")
	@Column(name = "username")
	private String username;

	@NotEmpty(message = "{login.password.must}")
//	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{5,12}$",message= "{customer.password.invalid}")
//	@Pattern(regexp= "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@#$!%*?&]).{4,20}$",message= "{customer.password.invalid}")
	@Column(name = "pword")
	private String password;

	@JsonFormat(pattern = "yyyy-MM-dd",shape = JsonFormat.Shape.STRING)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@Column(name = "dob")
	private LocalDate dob;

	
	@Valid
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "student_id", referencedColumnName = "student_id")
	private Student student;

	public Login() {
		super();
	}
	
	public Login(@NotEmpty(message = "{login.username.must}") String username,
			@NotEmpty(message = "{login.password.must}") String password, LocalDate dob) {
		super();
		this.username = username;
		this.password = password;
		this.dob = dob;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Long getLoginid() {
		return loginid;
	}

	public void setLoginid(Long loginid) {
		this.loginid = loginid;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

}
