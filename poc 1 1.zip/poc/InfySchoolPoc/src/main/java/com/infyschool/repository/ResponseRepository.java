package com.infyschool.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.infyschool.entity.Responses;

public interface ResponseRepository extends JpaRepository<Responses, Integer> {

}
