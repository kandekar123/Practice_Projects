package com.infyschool.entity;

import javax.validation.constraints.NotEmpty;

public class Siblings {
	@NotEmpty(message = "{siblings.type.must}")
	private String type;
	@NotEmpty(message = "{siblings.name.must}")
	private String name;
	@NotEmpty(message = "{siblings.job.must}")
	private String job;
	
	
	public Siblings(@NotEmpty(message = "{siblings.type.must}") String type,
			@NotEmpty(message = "{siblings.name.must}") String name,
			@NotEmpty(message = "{siblings.job.must}") String job) {
		super();
		this.type = type;
		this.name = name;
		this.job = job;
	}

	public Siblings() {
		// TODO Auto-generated constructor stub
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "Siblings [type=" + type + ", name=" + name + "job=" + job + "]";
	}
}
