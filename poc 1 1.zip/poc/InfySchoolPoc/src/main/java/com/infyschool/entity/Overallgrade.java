package com.infyschool.entity;

import javax.validation.constraints.NotEmpty;

public class Overallgrade {
	@NotEmpty(message = "Overall grade cannot be null or empty")
	private String overallgrade;

	@Override
	public String toString() {
		return "Overallgrade [overallgrade=" + overallgrade + "]";
	}

	public String getOverallgrade() {
		return overallgrade;
	}

	public void setOverallgrade(String overallgrade) {
		this.overallgrade = overallgrade;
	}

}
