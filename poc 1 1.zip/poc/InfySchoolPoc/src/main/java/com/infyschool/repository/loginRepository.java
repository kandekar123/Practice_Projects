package com.infyschool.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infyschool.entity.Login;

@Repository
public interface loginRepository extends JpaRepository<Login,Long> {
	
	public Login findByusername(String username);
	
	public boolean existsLoginByUsername(String username);

	
	

}
