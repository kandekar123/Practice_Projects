package com.infyschool.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface DemoRepository<T> {
	
	public void save(T t);
	
	public T findByYear(int admissionYear);

}
