package com.infyschool.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "loggertable")
@Component
public class Loggertab {

	@Id
	@GeneratedValue
	@Column(name = "login_id")
	private Long loginid;

	private String message;

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getLoginid() {
		return loginid;
	}

	public String getMessage() {
		return message;
	}

	public void setLoginid(Long loginid) {
		this.loginid = loginid;
	}

	public Loggertab() {
		super();

	}

}