package com.infyschool.entity;

import javax.validation.constraints.NotEmpty;

public class Mother {
	@NotEmpty(message = "{mother.name.must}")
	private String name;
	@NotEmpty(message = "{mother.dob.must}")
	private String dob;
	@NotEmpty(message = "{mother.job.must}")
	private String job;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "Mother [name=" + name + ", dob=" + dob + ", job=" + job + "]";
	}

}
