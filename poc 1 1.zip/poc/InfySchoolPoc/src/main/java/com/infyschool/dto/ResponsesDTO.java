package com.infyschool.dto;

import java.sql.Time;

import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.infyschool.entity.Answer;

public class ResponsesDTO {
	public Integer studentId;

	public List<Answer> answer;

	@DateTimeFormat(pattern = "hh:mm a")
	public Time time_of_attempt;

	public ResponsesDTO(Integer studentId, List<Answer> answer, Time time_of_attempt) {
		super();
		this.studentId = studentId;
		this.answer = answer;
		this.time_of_attempt = time_of_attempt;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	public Time getTime_of_attempt() {
		return time_of_attempt;
	}

	public void setTime_of_attempt(Time time_of_attempt) {
		this.time_of_attempt = time_of_attempt;
	}

	@Override
	public String toString() {
		return "Response [studentId=" + studentId + ", answer=" + answer + ", time_of_attempt=" + time_of_attempt + "]";
	}
}
