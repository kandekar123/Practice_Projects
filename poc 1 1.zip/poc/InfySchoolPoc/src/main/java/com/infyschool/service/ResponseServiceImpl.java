package com.infyschool.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infyschool.entity.Answer;
import com.infyschool.entity.MyResponses;
import com.infyschool.entity.Question;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Responses;
import com.infyschool.entity.Student;
import com.infyschool.exception.ServiceException;
import com.infyschool.repository.MyResponseRepo;
import com.infyschool.repository.QuestionRepository;
import com.infyschool.repository.ResponseRepository;
import com.infyschool.repository.StudentRepository;

@Service
public class ResponseServiceImpl implements ResponseService {

	@Autowired
	public ResponseRepository answerRepo;

	@Autowired
	public StudentRepository repo;

	@Autowired
	public QuestionRepository quest;

	@Autowired
	public MyResponseRepo myrepo;

	private static final Logger LOGGER = LoggerFactory.getLogger(ResponseServiceImpl.class);
	private static final String Classname = ResponseServiceImpl.class.getName();

	public Responses saveAnswers(Responses response, Long id) throws ServiceException {
		final String methodname = "saveAnswers()";
		LOGGER.info("ENTERING" + methodname + "Classname" + Classname + "time" + LocalDateTime.now());
		if (response.getStudent().getIqScore() == null || response.getStudent().getIqScore() < 0
				|| response.getStudent().getIqScore() > 100) {
			throw new ServiceException("Not valid iq score(must be in between 0 and 100), or iq score is null");
		} else {
			Optional<Student> studentRepo = repo.findById(id);
			Student sdb = studentRepo.get();
			if (sdb == null) {
				throw new ServiceException("Could not find student with the given student id.");
			} else {
				if (sdb.getIqScore() < response.getStudent().getIqScore()) {
					sdb.setIqScore(response.getStudent().getIqScore());
				}
				sdb.setNoOfAttempts(sdb.getNoOfAttempts() + 1);
				Responses res = new Responses();

				res.setStudent(sdb);
				res.setStudent_id(sdb.getStudentId());
				res.setAnswer(response.getAnswer());
				res.setTime_of_attempt(response.getTime_of_attempt());
				res.setCurrentIqScore(response.getStudent().getIqScore());
				Responses newRepo = answerRepo.save(res);
				LOGGER.info("EXITING " + methodname + "classname" + Classname + "returning" + newRepo + "time"
						+ LocalDateTime.now());
				return newRepo;
			}
		}

	}

	public List<Answer> returnAnswer(QuestionList questions) throws ServiceException {
		final String methodname = "returnAnswer()";
		LOGGER.info("ENTERING" + methodname + "Classname" + Classname + "time" + LocalDateTime.now());
		List<Integer> a = questions.getQuestionId();
		if (Collections.max(a) <= 30 && Collections.min(a) >= 1) {
			List<Question> ques = quest.findAllById(questions.getQuestionId());
			List<Answer> answerList = new ArrayList<>();
			ques.forEach(q -> {
				Answer ad = new Answer();
				ad.setQn(q.getQuesId());
				ad.setAns(q.getAnswer());
				answerList.add(ad);
			});
			LOGGER.info("EXITING "+methodname + "classname" +Classname +"returning"+answerList +"time" +LocalDateTime.now());
			return answerList;
		} else
			throw new ServiceException("Minimum question_id is 1 and maximum question id_is 30");
	}

	public List<MyResponses> myResponse(Long id) {
		final String methodname = "returnAnswer()";
		LOGGER.info("ENTERING" + methodname + "Classname" + Classname + "time" + LocalDateTime.now());
		List<MyResponses> myresponse = myrepo.findMyResponse(id);
		LOGGER.info("EXITING "+methodname + "classname" +Classname +"returning"+myresponse +"time" +LocalDateTime.now());
		return myresponse;
	}
}
