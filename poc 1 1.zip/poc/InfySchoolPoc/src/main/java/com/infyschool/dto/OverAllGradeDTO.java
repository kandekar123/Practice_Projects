package com.infyschool.dto;

public class OverAllGradeDTO {

	private String overallgrade;

	public String getOverallgrade() {
		return overallgrade;
	}

	public void setOverallgrade(String overallgrade) {
		this.overallgrade = overallgrade;
	}

	@Override
	public String toString() {
		return "OverAllGradeDTO [overallgrade=" + overallgrade + "]";
	}

}
