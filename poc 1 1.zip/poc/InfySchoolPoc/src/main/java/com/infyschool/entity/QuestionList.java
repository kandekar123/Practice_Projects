package com.infyschool.entity;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class QuestionList {
	
	@NotNull(message="{questionList.must}")
	@Size(min = 1,max = 10,message = "{questionlist.questionlistsize}")
	public List<Integer> questionId;

	public List<Integer> getQuestionId() {
		return questionId;
	}

	public void setQuestionId(List<Integer> questionId) {
		this.questionId = questionId;
	}

	@Override
	public String toString() {
		return "QuestionList [questionId=" + questionId + "]";
	}

}