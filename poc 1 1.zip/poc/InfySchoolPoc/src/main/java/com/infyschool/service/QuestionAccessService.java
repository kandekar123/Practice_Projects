package com.infyschool.service;

import java.util.Set;

import com.infyschool.entity.QuestionAccess;

public interface QuestionAccessService {

	public Set<QuestionAccess> findRandomQuestions();

}
