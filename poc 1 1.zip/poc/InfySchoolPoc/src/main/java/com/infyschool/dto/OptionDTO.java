package com.infyschool.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OptionDTO {

	@JsonProperty("option a")
	public String a;
	@JsonProperty("option b")
	public String b;
	@JsonProperty("option c")
	public String c;
	@JsonProperty("option d")
	public String d;

	public OptionDTO() {
		super();
	}

	public OptionDTO(String a, String b, String c, String d) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}

	@Override
	public String toString() {
		return "Option [a=" + a + ", b=" + b + ", c=" + c + ",d= " + d + "]";
	}
}
