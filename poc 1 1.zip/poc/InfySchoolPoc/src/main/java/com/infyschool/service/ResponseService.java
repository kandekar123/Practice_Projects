package com.infyschool.service;

import java.util.List;
import com.infyschool.entity.Answer;
import com.infyschool.entity.MyResponses;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Responses;
import com.infyschool.exception.ServiceException;

public interface ResponseService {

	public Responses saveAnswers(Responses response, Long id) throws ServiceException;

	public List<Answer> returnAnswer(QuestionList question) throws ServiceException;

	public List<MyResponses> myResponse(Long id);

}
