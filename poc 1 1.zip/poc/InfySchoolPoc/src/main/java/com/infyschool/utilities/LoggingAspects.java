//package com.infyschool.utilities;
//
//import java.time.LocalDateTime;
//
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.infyschool.controller.StudentController;
//import com.infyschool.entity.Loggertab;
//import com.infyschool.repository.LoggerRepo;
//
//
//@Component
//@Aspect
//public class LoggingAspects {
//
//	 private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspects.class);
//		private static final String CLASSNAME = LoggingAspects.class.getName();
//		
//		@Autowired
//		LoggerRepo rep;
//		
//		@Around("execution(* com.infyschool.Service.*.*(..))")
//		public Object loggingFromService(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
//			long counter=0;
//			counter++;
//			MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
//			Object result = proceedingJoinPoint.proceed();
//			LOGGER.info("Entering {}"+methodSignature.getName()  +"className"+ methodSignature.getDeclaringType().getSimpleName() +"time"+LocalDateTime.now());
//			
//			Loggertab lgtb = new Loggertab();
//			lgtb.setMessage("Entering {}"+methodSignature.getName()  +"className"+ methodSignature.getDeclaringType().getSimpleName() +"time"+LocalDateTime.now());
//			lgtb.setLoginid(counter++);
//			rep.save(lgtb);
//			
//			Loggertab logexit = new Loggertab();
//			LOGGER.info("Exiting {}  : "+methodSignature.getName()  +"   className"+ methodSignature.getDeclaringType().getSimpleName() +"returning    "+methodSignature.getReturnType().getName()+"   time"+LocalDateTime.now());
//			logexit.setMessage("Exiting {}  : "+methodSignature.getName()  +"   className"+ methodSignature.getDeclaringType().getSimpleName() +"returning    "+methodSignature.getReturnType().getName()+"   time"+LocalDateTime.now());
//			logexit.setLoginid(counter+1);
//			return rep.save(logexit);
//			
//		}
//		
//		
//		
//		
//		
//		
//	
//}
//
//
