package com.infyschool.service;

import org.springframework.data.domain.Page;
import com.infyschool.entity.Login;
import com.infyschool.entity.MyStudentData;
import com.infyschool.entity.Student;
import com.infyschool.exception.ServiceException;

public interface StudentService {
	public Page<Student> getAllStudentbyYear(int admissionYear, int page, int size) throws ServiceException;

	public Student getAllStudentbyId(long studentId) throws ServiceException;

	public Student updateStudent(long studentId, Student dataentity) throws ServiceException;

	public String loginService(String username, String pword) throws ServiceException;

	public Student FullData(long studentId, MyStudentData student);

	public Long register(Login dataentity) throws ServiceException;
}
