package com.infyschool.controller;

import java.time.LocalDateTime;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infyschool.dto.ResponseDTOO;
import com.infyschool.entity.Loggertab;
import com.infyschool.entity.Login;
import com.infyschool.entity.MyStudentData;
import com.infyschool.entity.Student;
import com.infyschool.service.LogService;
import com.infyschool.service.StudentService;
import com.infyschool.exception.ServiceException;

@RestController
@RequestMapping(value = "/student")
@Validated
public class StudentController {

	private static final Logger LOGGER = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	private StudentService service;

	@Autowired
	LogService log;

	@Autowired
	private Loggertab logTab;

	private String message = null;

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@GetMapping("/students/{admissionYear}")
	public ResponseEntity<Page<Student>> getAllStudentbyYear(
			@PathVariable("admissionYear") @Min(value = 2000, message = "Please enter the year greater than 2000") @Max(value = 2020, message = "Please enter the year less than 2020") int admissionYear,
			@RequestParam("page") int page, @RequestParam("size") int size) throws ServiceException {
		LOGGER.info("Fetched paginated student Data from Student Repo " + LocalDateTime.now(),
				service.getAllStudentbyYear(admissionYear, page, size) + "200 OK");
		logTab.setMessage("Fetched paginated student Data from Student Repo  " + LocalDateTime.now());
		log.save(logTab);
		return new ResponseEntity<>(service.getAllStudentbyYear(admissionYear, page, size), HttpStatus.OK);

	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@GetMapping(value = "/{studentId}")
	public ResponseEntity<Student> getAllStudentbyId(
			@PathVariable("studentId") @Min(value = 1, message = "Please enter the correct id") @Max(value = 100000000, message = "Please enter the correct id") long studentId)
			throws ServiceException {
		LOGGER.info("Fetched all  student Data by using studentid " + LocalDateTime.now(),
				service.getAllStudentbyId(studentId) + "200 OK");
		logTab.setMessage("Fetched all  student Data by using studentid  " + LocalDateTime.now());
		log.save(logTab);
		return new ResponseEntity<>(service.getAllStudentbyId(studentId), HttpStatus.OK);
	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PutMapping(value = "/{studentId}")
	public ResponseEntity<Student> updateStudent(@PathVariable("studentId") long studentId,
			@Valid @RequestBody Student student) throws ServiceException {
		message = "student data updated using studentid = " + studentId + "  " + LocalDateTime.now() + HttpStatus.OK;
		LOGGER.info(message, service.updateStudent(studentId, student) + "200 OK");
		logTab.setMessage(message);
		log.save(logTab);
		return new ResponseEntity<>(service.updateStudent(studentId, student), HttpStatus.OK);

	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PostMapping(value = "/register")
	public ResponseEntity<String> registerstudentId(@Valid @RequestBody Login dataentity) throws ServiceException {

		Long studentId = service.register(dataentity);

		String response = "Successfully Registered StudentId : " + studentId;
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PutMapping(value = "/fulldetails")
	public ResponseEntity<Student> fulldata(@Min(1) @Max(100000000) @RequestParam("studentId") long studentId,
			@Valid @RequestBody MyStudentData student) throws ServiceException {

		message = "Update the Student data of Student Id :" + studentId + "with" + student + " " + LocalDateTime.now();
		LOGGER.info(message, service.FullData(studentId, student));
		logTab.setMessage(message);
		log.save(logTab);

		return ResponseEntity.ok(service.FullData(studentId, student));
	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PostMapping(value = "/login")
	public ResponseEntity<ResponseDTOO> login(@Valid @RequestBody Login login) throws ServiceException {
		ResponseDTOO rdto = new ResponseDTOO();
		String loginid = service.loginService(login.getUsername(), login.getPassword());

		if (loginid == null) {
			rdto.setLoginid(null);
			rdto.setResponse(false);
			message = "Login Failed " + LocalDateTime.now();
		} else {
			rdto.setLoginid(loginid);
			rdto.setResponse(true);
			message = "Login Succesfull for" + login.getUsername();
		}

		LOGGER.info(message);
		logTab.setMessage(message);
		log.save(logTab);
		return new ResponseEntity<>(rdto, HttpStatus.OK);
	}
}
