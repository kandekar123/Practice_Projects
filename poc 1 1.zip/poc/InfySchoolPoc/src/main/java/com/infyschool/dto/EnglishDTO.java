package com.infyschool.dto;

public class EnglishDTO {

	private float written;
	private float viva;
	private float assignment;

	public float getWritten() {
		return written;
	}

	public void setWritten(float written) {
		this.written = written;
	}

	public float getViva() {
		return viva;
	}

	public void setViva(float viva) {
		this.viva = viva;
	}

	public float getAssignment() {
		return assignment;
	}

	public void setAssignment(float assignment) {
		this.assignment = assignment;
	}

	@Override
	public String toString() {
		return "EnglishDTO [written=" + written + ", viva=" + viva + ", assignment=" + assignment + "]";
	}

}
