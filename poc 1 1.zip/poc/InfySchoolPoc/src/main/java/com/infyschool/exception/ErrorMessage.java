package com.infyschool.exception;

import java.time.LocalTime;

public class ErrorMessage {

	private LocalTime timestamp;
	private String message;
	private int errorcode;

	public ErrorMessage() {
		super();
	}

	public ErrorMessage(LocalTime timestamp, String message, int errorcode) {
		super();
		this.timestamp = timestamp;
		this.message = message;
	}

	public LocalTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(int errorcode) {
		this.errorcode = errorcode;
	}

}
