package com.infyschool.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

@Entity
@Table(name = "reference_table")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Question {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "question_id")
	public Integer quesId;

	@Column(name = "question")
	public String question;

	@Column(name = "answer_option")
	@Type(type = "jsonb")
	public Option option;

	@Column(name = "multiple_answer")
	public String multians;

	@Column(name = "answer")
	public String answer;

	public Question() {
		super();
	}

	public Question(Integer quesId, String question, Option option, String multians, String answer) {
		super();
		this.quesId = quesId;
		this.question = question;
		this.option = option;
		this.multians = multians;
		this.answer = answer;
	}

	public Integer getQuesId() {
		return quesId;
	}

	public void setQuesId(Integer quesId) {
		this.quesId = quesId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Option getOption() {
		return option;
	}

	public void setOption(Option option) {
		this.option = option;
	}

	public String getMultians() {
		return multians;
	}

	public void setMultians(String multians) {
		this.multians = multians;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Question [QuestionId=" + quesId + ", Question=" + question + ", Answer_option=" + option
				+ ", Multiple_Answer=" + multians + "," + " answer=" + answer + "" + "]";
	}

}