package com.infyschool.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class StudentDTO {
	
	@NotNull(message="studentId shouldn't be null")
	private Long studentId;
	
	@NotNull(message="studentName shouldn't be null")
	@NotBlank(message="studentName shouldn't be empty")
	private String studentName;
	
	@NotNull(message="admissionYear shouldn't be null")
	@Min(1000)
	@Max(9999)
	private int admissionYear;
	
	private StudentDataDTO studentData;
	private LoginDTO loginDTO;
	
	
	
	
	
	public StudentDTO(Long studentId, String studentName, int admissionYear, StudentDataDTO studentData,
			LoginDTO dto) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.admissionYear = admissionYear;
		this.studentData = studentData;
		this.loginDTO= dto;
		
	}




	public LoginDTO getLoginDTO() {
		return loginDTO;
	}




	public void setLoginDTO(LoginDTO loginDTO) {
		this.loginDTO = loginDTO;
	}




	public Long getStudentId() {
		return studentId;
	}




	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}




	public String getStudentName() {
		return studentName;
	}




	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}




	public int getAdmissionYear() {
		return admissionYear;
	}




	public void setAdmissionYear(int admissionYear) {
		this.admissionYear = admissionYear;
	}




	public StudentDataDTO getStudentData() {
		return studentData;
	}




	public void setStudentData(StudentDataDTO studentData) {
		this.studentData = studentData;
	}




	@Override
	public String toString() {
		return "StudentDTO [studentId=" + studentId + ", studentName=" + studentName + ", admissionYear="
				+ admissionYear + ", studentData=" + studentData + ", loginDTO=" + loginDTO + "]";
	}



}
