package com.infyschool.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.infyschool.entity.Option;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuestionDTO {

	public Integer quesId;
	public String question;
	public Option option;
	public String multians;
	public String answer;

	public QuestionDTO() {
		super();
	}

	public QuestionDTO(Integer quesId, String question, Option option, String multians, String answer) {
		super();
		this.quesId = quesId;
		this.question = question;
		this.option = option;
		this.multians = multians;
		this.answer = answer;
	}

	public Integer getQuesId() {
		return quesId;
	}

	public void setQuesId(Integer quesId) {
		this.quesId = quesId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Option getOption() {
		return option;
	}

	public void setOption(Option option) {
		this.option = option;
	}

	public String getMultians() {
		return multians;
	}

	public void setMultians(String multians) {
		this.multians = multians;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Question [QuestionId=" + quesId + ", Question=" + question + ", Answer_option=" + option
				+ ", Multiple_Answer=" + multians + ", answer=" + answer + "]";
	}
}
