package com.infyschool.entity;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class StudentData {
	@NotNull(message = "{studentdata.father.must}")
	@Valid
	private Father father;
	@NotNull(message = "{studentdata.mother.must}")
	@Valid
	private Mother mother;
	@NotNull(message = "{studentdata.siblings.must}")
	@Valid
	private List<Siblings> siblings;
	@NotNull(message = "{studentdata.grade.must}")
	@Valid
	private List<Grade> grade;
	@NotNull(message = "{studentdata.Overallgrade.must}")
	@Valid
	private Overallgrade overallgrade;

	public Father getFather() {
		return father;
	}

	public void setFather(Father father) {
		this.father = father;
	}

	public Mother getMother() {
		return mother;
	}

	public void setMother(Mother mother) {
		this.mother = mother;
	}

	public List<Siblings> getSiblings() {
		return siblings;
	}

	public void setSiblings(List<Siblings> siblings) {
		this.siblings = siblings;
	}

	public List<Grade> getGrade() {
		return grade;
	}

	public void setGrade(List<Grade> grade) {
		this.grade = grade;
	}

	public Overallgrade getOverallgrade() {
		return overallgrade;
	}

	public void setOverallgrade(Overallgrade overallgrade) {
		this.overallgrade = overallgrade;
	}

	@Override
	public String toString() {
		return "StudentDataEntity [father=" + father + ", mother=" + mother + ", siblings=" + siblings + ", grade="
				+ grade + ", overallgrade=" + overallgrade + "]";
	}

}
