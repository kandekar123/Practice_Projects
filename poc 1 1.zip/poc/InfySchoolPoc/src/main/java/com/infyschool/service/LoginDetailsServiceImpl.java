package com.infyschool.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.infyschool.entity.Login;
import com.infyschool.entity.LoginUserDetails;
import com.infyschool.repository.loginRepository;

@Service
public class LoginDetailsServiceImpl implements UserDetailsService {

	@Autowired
	loginRepository repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Login login = repo.findByusername(username);
		if (login == null) {
			throw new UsernameNotFoundException("users not found");
		}

		return new LoginUserDetails(login);
	}

}
