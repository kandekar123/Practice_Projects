package com.infyschool.controller;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.infyschool.entity.QuestionAccess;
import com.infyschool.service.QuestionAccessService;

@RestController
@RequestMapping(value = "/question")
@Validated
public class QuestionController {

	@Autowired
	private QuestionAccessService questionService;

//	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/findRandomQuestion")
	public Set<QuestionAccess> findRandomQuestion() {
		return questionService.findRandomQuestions();
	}
	
}
