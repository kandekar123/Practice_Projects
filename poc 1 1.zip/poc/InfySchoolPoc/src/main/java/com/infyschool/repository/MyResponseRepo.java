package com.infyschool.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infyschool.entity.MyResponses;

public interface MyResponseRepo extends JpaRepository<MyResponses, Integer>{
	@Query(value="select * from response_log_table u where u.student_id=?1 order by time_of_attempt",nativeQuery=true)
	public List<MyResponses>findMyResponse(Long student_id);
}
