package com.infyschool.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Answer implements Serializable{
	@JsonProperty("qn")
	public Integer qn;

	@JsonProperty("ans")
	public String ans;
	
	

	public Answer(Integer qn, String ans) {
		super();
		this.qn = qn;
		this.ans = ans;
	}

	public Answer() {
		// TODO Auto-generated constructor stub
	}

	public Integer getQn() {
		return qn;
	}

	public void setQn(Integer qn) {
		this.qn = qn;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	@Override
	public String toString() {
		return "Answer [qn=" + qn + ", ans=" + ans + "]";
	}

}
