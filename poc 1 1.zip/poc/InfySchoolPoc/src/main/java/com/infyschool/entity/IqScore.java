package com.infyschool.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

@Entity
@Table(name= "tablndemo")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class IqScore {
	@Id
	@Column(name="student_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer studentId;
	
	@Column(name="iq_score")
	public Integer iqScore;
	
	@Column(name="no_of_attempts")
	public Integer noOfAttempts;

	public IqScore(Integer studentId, Integer iqScore, Integer noOfAttempts) {
		super();
		this.studentId = studentId;
		this.iqScore = iqScore;
		this.noOfAttempts = noOfAttempts;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getIqScore() {
		return iqScore;
	}

	public void setIqScore(Integer iqScore) {
		this.iqScore = iqScore;
	}

	public Integer getNoOfAttempts() {
		return noOfAttempts;
	}

	public void setNoOfAttempts(Integer noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	@Override
	public String toString() {
		return "IqScore [studentId=" + studentId + ", iqScore=" + iqScore + ", noOfAttempts=" + noOfAttempts + "]";
	}
	
	
}
