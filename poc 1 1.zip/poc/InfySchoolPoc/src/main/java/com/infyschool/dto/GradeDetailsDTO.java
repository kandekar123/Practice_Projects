package com.infyschool.dto;

public class GradeDetailsDTO {

	private MathematicsDTO mathematics;
	private SocialScienceDTO socialscience;
	private ScienceDTO science;
	private EnglishDTO english;
	private MalayalamDTO malayalam;

	public MathematicsDTO getMathematics() {
		return mathematics;
	}

	public void setMathematics(MathematicsDTO mathematics) {
		this.mathematics = mathematics;
	}

	public SocialScienceDTO getSocialscience() {
		return socialscience;
	}

	public void setSocialscience(SocialScienceDTO socialscience) {
		this.socialscience = socialscience;
	}

	public ScienceDTO getScience() {
		return science;
	}

	public void setScience(ScienceDTO science) {
		this.science = science;
	}

	public EnglishDTO getEnglish() {
		return english;
	}

	public void setEnglish(EnglishDTO english) {
		this.english = english;
	}

	public MalayalamDTO getMalayalam() {
		return malayalam;
	}

	public void setMalayalam(MalayalamDTO malayalam) {
		this.malayalam = malayalam;
	}

	@Override
	public String toString() {
		return "GradeDetailsDTO [mathematics=" + mathematics + ", socialscience=" + socialscience + ", science="
				+ science + ", english=" + english + ", malayalam=" + malayalam + "]";
	}

}
