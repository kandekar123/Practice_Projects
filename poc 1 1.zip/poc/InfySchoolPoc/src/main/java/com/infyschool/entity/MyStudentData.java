package com.infyschool.entity;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

public class MyStudentData {
	@Valid
	@NotNull(message = "{mystudentdata.studentData.must}")
	public StudentData studentData;

	public StudentData getStudentData() {
		return studentData;
	}

	public void setStudentData(StudentData studentData) {
		this.studentData = studentData;
	}
	
}
