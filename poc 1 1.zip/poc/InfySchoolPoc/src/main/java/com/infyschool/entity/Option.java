package com.infyschool.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Option {
	
	@JsonProperty("a")
	public String a;
	
	@JsonProperty("b")
	public String b;
	
	@JsonProperty("c")
	public String c;
	
	@JsonProperty("d")
	public String d;

	
	
	public Option() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Option(String a, String b, String c, String d) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}



	public String getA() {
		return a;
	}



	public void setA(String a) {
		this.a = a;
	}



	public String getB() {
		return b;
	}



	public void setB(String b) {
		this.b = b;
	}



	public String getC() {
		return c;
	}



	public void setC(String c) {
		this.c = c;
	}



	public String getD() {
		return d;
	}



	public void setD(String d) {
		this.d = d;
	}
	
	
}