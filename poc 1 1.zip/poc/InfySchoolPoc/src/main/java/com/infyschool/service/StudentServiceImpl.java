package com.infyschool.service;

import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import com.infyschool.entity.*;
import com.infyschool.repository.*;
import com.infyschool.exception.*;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

	@Autowired
	public StudentRepository repo;

	@Autowired
	public loginRepository loginrepo;

	@Autowired
	public PasswordEncoder passwordEncoder;

	@Autowired
	public LogService logservice;

	private static final Logger LOGGER = LoggerFactory.getLogger(StudentServiceImpl.class);
	private static final String Classname = StudentServiceImpl.class.getName();

	@Override
	public Page<Student> getAllStudentbyYear(int admissionYear, int page, int size) throws ServiceException {
		// TODO Auto-generated method stub
		final String methodname = "getAllStudentbyYear()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());

		Pageable p = PageRequest.of(page, size);
		Page<Student> studentlist = repo.findByAdmissionYear(admissionYear, p);

		if (studentlist.isEmpty()) {

			throw new ServiceException("student not found in this year");

		}
		LOGGER.info("EXITING" + methodname,
				"className" + Classname + "returning" + studentlist + "time" + LocalDateTime.now());

		return studentlist;
	}

	@Override
	public Student getAllStudentbyId(long studentId) throws ServiceException {
		final String methodname = "getAllStudentbyId()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());
		Student std = repo.findBystudentId(studentId);
		if (ObjectUtils.isEmpty(std)) {
			throw new ServiceException("No student available in this Id");
		} else {
			LOGGER.info("EXITING" + methodname,
					"className" + Classname + "returning" + std + "time" + LocalDateTime.now());
			return std;
		}
	}

	@Override
	public Student updateStudent(long studentId, Student dataentity) throws ServiceException {

		final String methodname = "updateStudent()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());
		Student std1 = null;

		if (!ObjectUtils.isEmpty(dataentity)) {

			if (dataentity.getStudentId().equals(studentId)) {

				std1 = repo.findBystudentId(studentId);
			}

			if (ObjectUtils.isEmpty(std1)) {
				LOGGER.error("record not found",
						"methodname" + methodname + "className" + Classname + "time" + LocalDateTime.now());
				throw new ServiceException("record not found");
			}

			std1.setAdmissionYear(dataentity.getAdmissionYear());
			if (!(dataentity.getStudentName().isBlank() && dataentity.getStudentName().isEmpty())) {
				std1.setStudentName(dataentity.getStudentName());
			}

			StudentData studentdata = new StudentData();
			if (!ObjectUtils.isEmpty(studentdata)) {
				Father fDTO = new Father();
				fDTO.setName(dataentity.getStudentData().getFather().getName());
				fDTO.setJob(dataentity.getStudentData().getFather().getJob());
				fDTO.setDob(dataentity.getStudentData().getFather().getDob());
				studentdata.setFather(fDTO);

				Mother mDto = new Mother();
				mDto.setName(dataentity.getStudentData().getMother().getName());
				mDto.setJob(dataentity.getStudentData().getMother().getJob());
				mDto.setDob(dataentity.getStudentData().getFather().getDob());
				studentdata.setMother(mDto);

				Overallgrade overallDto = new Overallgrade();
				overallDto.setOverallgrade(dataentity.getStudentData().getOverallgrade().getOverallgrade());
				studentdata.setOverallgrade(overallDto);

				List<Siblings> siblings = new ArrayList<>();

				List<Siblings> sdto = dataentity.getStudentData().getSiblings();

				sdto.forEach(ss -> {

					Siblings s = new Siblings();
					s.setName(ss.getName());
					s.setJob(ss.getJob());
					s.setType(ss.getType());

					siblings.add(s);

				});

				studentdata.setSiblings(siblings);

				List<Grade> grade = new ArrayList<>();
				List<Grade> gdto = dataentity.getStudentData().getGrade();
				gdto.forEach(g -> {

					Grade gg = new Grade();
					English e = new English();
					e.setAssignment(g.getEnglish().getAssignment());
					e.setViva(g.getEnglish().getViva());
					e.setWritten(g.getEnglish().getWritten());
					gg.setEnglish(e);

					Malayalam m = new Malayalam();
					m.setAssignment(g.getMalayalam().getAssignment());
					m.setViva(g.getMalayalam().getViva());
					m.setWritten(g.getMalayalam().getWritten());
					gg.setMalayalam(m);

					Mathematics mm = new Mathematics();
					mm.setAssignment(g.getMathematics().getAssignment());
					mm.setViva(g.getMathematics().getViva());
					mm.setWritten(g.getMathematics().getWritten());
					gg.setMathematics(mm);

					Socialscience ss = new Socialscience();
					ss.setAssignment(g.getSocialscience().getAssignment());
					ss.setViva(g.getSocialscience().getViva());
					ss.setWritten(g.getSocialscience().getWritten());
					gg.setSocialscience(ss);

					Science bs = new Science();
					bs.setAssignment(g.getScience().getAssignment());
					bs.setViva(g.getScience().getViva());
					bs.setWritten(g.getSocialscience().getWritten());
					gg.setScience(bs);

					grade.add(gg);

				});

				studentdata.setGrade(grade);
				std1.setStudentData(studentdata);
			}
		}

		Student std2 = repo.save(std1);
		LOGGER.info("EXITING" + methodname,
				"className" + Classname + "returning" + std2 + "time" + LocalDateTime.now());
		return std2;
	}

	@Override
	public Long register(Login dataentity) throws ServiceException {
		final String methodname = "register()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());
		if (dataentity.getDob() == null) {
			throw new ServiceException("Please enter dob");
		}
		if (loginrepo.existsLoginByUsername(dataentity.getUsername())) {
			throw new ServiceException("Username already exists,please provide a new one");
		} else {
			Login loginEntity = new Login(dataentity.getUsername(),passwordEncoder.encode(dataentity.getPassword()),dataentity.getDob());
//			loginEntity.setUsername(dataentity.getUsername());
//			loginEntity.setPassword(passwordEncoder.encode(dataentity.getPassword()));
//			loginEntity.setDob(dataentity.getDob());
			loginEntity = loginrepo.save(loginEntity);
			Student studentEntity = dataentity.getStudent();
			studentEntity.setIqScore(0);
			studentEntity.setStudentId(loginEntity.getLoginid());
			Student studentsave = repo.save(studentEntity);
			LOGGER.info("EXITING" + methodname, "className" + Classname + "returning studentId"
					+ studentsave.getStudentId() + "time" + LocalDateTime.now());
			return studentEntity.getStudentId();
		}
	}

	@Override
	public Student FullData(long studentId, MyStudentData student) {

		final String methodname = "FullData()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());

		Optional<Student> studentdb = repo.findById(studentId);
		Student s = studentdb.get();
		s.setStudentData(student.getStudentData());
		LOGGER.info("EXITING" + methodname,
				"className" + Classname + "returning" + repo.save(s) + "time" + LocalDateTime.now());
		return repo.save(s);

	}

	@Override
	public String loginService(String username, String password) throws ServiceException {
		final String methodname = "loginService(String username,String password)";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());
		String loginid = "";
		Login login = loginrepo.findByusername(username);
		if (login == null) {
			loginid = null;
			throw new ServiceException("No such user exists");
		} else {

			boolean blu = passwordEncoder.matches(password, login.getPassword());
			if (blu) {
				loginid = login.getLoginid().toString();
			} else {
				loginid = null;
			}
		}
		LOGGER.info("EXITING" + methodname,
				"className" + Classname + "returning" + loginid + "time" + LocalDateTime.now());
		return loginid;
	}

}
