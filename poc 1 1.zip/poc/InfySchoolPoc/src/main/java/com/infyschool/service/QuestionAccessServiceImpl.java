package com.infyschool.service;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infyschool.entity.QuestionAccess;
import com.infyschool.repository.QuestionAccessRepository;



@Service
public class QuestionAccessServiceImpl implements QuestionAccessService {
	@Autowired
	public QuestionAccessRepository questionRepository;
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuestionAccessServiceImpl.class);
	private static final String Classname = QuestionAccessServiceImpl.class.getName();


	public Set<QuestionAccess> findRandomQuestions() {
		final String methodname = "findRandomQuestions()";
		LOGGER.info("Entering {}" + methodname + "className" + Classname + "time" + LocalDateTime.now());
		Set<QuestionAccess> a = new LinkedHashSet<QuestionAccess>();
		a = (questionRepository.findRandomQuestions());
		LOGGER.info("EXITING "+methodname + "classname" +Classname +"returning"+a +"time" +LocalDateTime.now());
		return a;
	}

}
