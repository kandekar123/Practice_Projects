package com.infyschool.dto;

public class ResponseDTO {

	private boolean response;
	private String loginid;

	public ResponseDTO(boolean response, String loginid) {
		super();
		this.response = response;
		this.loginid = loginid;
	}

	public boolean isResponse() {
		return response;
	}

	public void setResponse(boolean response) {
		this.response = response;
	}

	public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	@Override
	public String toString() {
		return "ResponseDTO [response=" + response + ", loginid=" + loginid + "]";
	}

}
