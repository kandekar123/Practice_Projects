package com.infyschool.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infyschool.entity.QuestionAccess;

public interface QuestionAccessRepository extends JpaRepository<QuestionAccess,Integer>{
	@Query(nativeQuery=true, value="SELECT * FROM  reference_table  ORDER BY random() LIMIT 10")
	public Set<QuestionAccess> findRandomQuestions();
}
