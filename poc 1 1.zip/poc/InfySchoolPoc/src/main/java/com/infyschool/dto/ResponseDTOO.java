package com.infyschool.dto;

public class ResponseDTOO {

	private boolean response;
	private String loginid;

	public boolean isResponse() {
		return response;
	}

	public void setResponse(boolean response) {
		this.response = response;
	}

	public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	@Override
	public String toString() {
		return "ResponseDTOO [response=" + response + ", loginid=" + loginid + "]";
	}

}
