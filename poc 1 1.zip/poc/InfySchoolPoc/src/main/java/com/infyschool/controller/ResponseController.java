package com.infyschool.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.infyschool.entity.Answer;
import com.infyschool.entity.MyResponses;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Responses;
import com.infyschool.exception.ServiceException;
import com.infyschool.service.ResponseService;

@RestController
@RequestMapping(value = "/response")
@Validated
public class ResponseController {

	@Autowired
	public ResponseService responseService;

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PostMapping(value = "/answer")
	public Responses addAnswers(@Valid @RequestBody Responses response, @RequestParam("id") Long id) throws ServiceException {
		return responseService.saveAnswers(response, id);

	}

//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@PostMapping(value = "/returnanswer")
	public List<Answer> returnAnswer(@Valid @RequestBody QuestionList question) throws ServiceException {
		return responseService.returnAnswer(question);
	}
	
//	@CrossOrigin(origins = "http://localhost:4200")
	@CrossOrigin(origins = "*")
	@GetMapping(value = "/myresponse")
	public List<MyResponses>myResponses(@RequestParam("id")Long id){
		return responseService.myResponse(id);
	}
}
