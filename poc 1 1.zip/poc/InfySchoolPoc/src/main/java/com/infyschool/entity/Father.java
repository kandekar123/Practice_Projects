package com.infyschool.entity;

import javax.validation.constraints.NotEmpty;

public class Father {
	@NotEmpty(message = "{father.name.must}")
	private String name;
	@NotEmpty(message = "{father.dob.must}")
	private String dob;
	@NotEmpty(message = "{father.job.must}")
	private String job;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "Father [name=" + name + ", dob=" + dob + ", job=" + job + "]";
	}

}
