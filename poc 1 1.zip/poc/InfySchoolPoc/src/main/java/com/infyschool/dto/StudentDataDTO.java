package com.infyschool.dto;

import java.util.List;



public class StudentDataDTO {
	
	private FatherDetailsDTO fatherDetails;
	private MotherDetailsDTO motherDetails;
	private List<SiblingsDetailsDTO> siblingsDetails;
	private List<GradeDetailsDTO> gradeDetails;
	private OverAllGradeDTO overAllGrade;
	
	public FatherDetailsDTO getFatherDetails() {
		return fatherDetails;
	}
	public void setFatherDetails(FatherDetailsDTO fatherDetails) {
		this.fatherDetails = fatherDetails;
	}
	public MotherDetailsDTO getMotherDetails() {
		return motherDetails;
	}
	public void setMotherDetails(MotherDetailsDTO motherDetails) {
		this.motherDetails = motherDetails;
	}
	public List<SiblingsDetailsDTO> getSiblingsDetails() {
		return siblingsDetails;
	}
	public void setSiblingsDetails(List<SiblingsDetailsDTO> siblingsDetails) {
		this.siblingsDetails = siblingsDetails;
	}
	public List<GradeDetailsDTO> getGradeDetails() {
		return gradeDetails;
	}
	public void setGradeDetails(List<GradeDetailsDTO> gradeDetails) {
		this.gradeDetails = gradeDetails;
	}
	public OverAllGradeDTO getOverAllGrade() {
		return overAllGrade;
	}
	public void setOverAllGrade(OverAllGradeDTO overAllGrade) {
		this.overAllGrade = overAllGrade;
	}
	@Override
	public String toString() {
		return "StudentDataDTO [fatherDetails=" + fatherDetails + ", motherDetails=" + motherDetails
				+ ", siblingsDetails=" + siblingsDetails + ", gradeDetails=" + gradeDetails + ", overAllGrade="
				+ overAllGrade + "]";
	}

	
	
}
