package com.infyschool.entity;

import java.sql.Time;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

@Entity
@Table(name = "response_log_table")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MyResponses {
	@Id
	@Column(name = "q_id")
	public Integer q_id;

	@Column(name = "student_id")
	public Long student_id;

	@NotNull(message = "{response.answer.must}")
	@Column(name = "response")
	@Type(type = "jsonb")
	@JsonProperty("response")
	public List<Answer> answer;

	@NotNull(message = "{response.time_of_attempt.must}")
	@Column(name = "time_of_attempt")
	@DateTimeFormat(pattern = "hh:mm:ss")
	public Time time_of_attempt;

	@Column(name = "current_iq_score")
	public Integer currentIqScore;

	public Integer getQ_id() {
		return q_id;
	}

	public void setQ_id(Integer q_id) {
		this.q_id = q_id;
	}

	public Long getStudent_id() {
		return student_id;
	}

	public void setStudent_id(Long student_id) {
		this.student_id = student_id;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	public Time getTime_of_attempt() {
		return time_of_attempt;
	}

	public void setTime_of_attempt(Time time_of_attempt) {
		this.time_of_attempt = time_of_attempt;
	}

	public Integer getCurrentIqScore() {
		return currentIqScore;
	}

	public void setCurrentIqScore(Integer currentIqScore) {
		this.currentIqScore = currentIqScore;
	}
	
	
}
