package com.infyschool.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infyschool.entity.Loggertab;
import com.infyschool.repository.LoggerRepo;

@Service
@Transactional
public class LogService {

	@Autowired
	LoggerRepo repo;

	public void save(Loggertab l) {
		repo.save(l);
	}

	public List<Loggertab> getAllLogs() {
		return repo.findAll();
	}

}
