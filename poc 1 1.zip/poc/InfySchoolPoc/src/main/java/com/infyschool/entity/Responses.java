package com.infyschool.entity;

import java.io.Serializable;
import java.sql.Time;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

@Entity
@Table(name = "response_log_table")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Responses implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "res_seq", strategy = GenerationType.AUTO)
	@SequenceGenerator(name = "res_seq", sequenceName = "res_sequence", initialValue = 1, allocationSize = 1)
	@Column(name = "q_id")
	public Integer q_id;
	
	@Column(name = "student_id")
	public Long student_id;

	@NotNull(message = "{response.answer.must}")
	@Column(name = "response")
	@Type(type = "jsonb")
	@JsonProperty("response")
	public List<Answer> answer;

	@NotNull(message = "{response.time_of_attempt.must}")
	@Column(name = "time_of_attempt")
	@DateTimeFormat(pattern = "hh:mm:ss")
	public Time time_of_attempt;

	@Column(name = "current_iq_score")
	public Integer currentIqScore;

	@NotNull(message = "{response.student.must}")
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "student_id", referencedColumnName = "student_id", insertable = false, updatable = false)
	public Student student;

	public Integer getQ_id() {
		return q_id;
	}

	public void setQ_id(Integer q_id) {
		this.q_id = q_id;
	}

	public Long getStudent_id() {
		return student_id;
	}

	public void setStudent_id(Long student_id) {
		this.student_id = student_id;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	public Time getTime_of_attempt() {
		return time_of_attempt;
	}

	public void setTime_of_attempt(Time time_of_attempt) {
		this.time_of_attempt = time_of_attempt;
	}

	public Integer getCurrentIqScore() {
		return currentIqScore;
	}

	public void setCurrentIqScore(Integer currentIqScore) {
		this.currentIqScore = currentIqScore;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "Responses [q_id=" + q_id + ", student_id=" + student_id + ", answer=" + answer + ", time_of_attempt="
				+ time_of_attempt + ", currentIqScore=" + currentIqScore + ", student=" + student + "]";
	}

}