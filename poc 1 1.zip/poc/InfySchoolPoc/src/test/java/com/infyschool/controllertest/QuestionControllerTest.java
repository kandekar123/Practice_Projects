package com.infyschool.controllertest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.LinkedHashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.infyschool.controller.QuestionController;
import com.infyschool.entity.Option;
import com.infyschool.entity.QuestionAccess;
import com.infyschool.repository.QuestionAccessRepository;
import com.infyschool.service.QuestionAccessService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = QuestionController.class)
public class QuestionControllerTest {
	@Autowired
	public MockMvc mockMvc;

	@MockBean
	public QuestionAccessService questionService;

	@MockBean
	public QuestionAccessRepository questionRepository;

	@MockBean
	public UserDetailsService userdetails;

	@Test
	public void testFindRandomQuestion() throws Exception {
		Set<QuestionAccess> questions = new LinkedHashSet<>();
		questions.add(new QuestionAccess(1, "What is the name of NationalBird?",
				new Option("Ostrich", "Peacock", "HummingBird", "Cockoo"), "Y"));
		questions.add(new QuestionAccess(2, "'OS' computer abbreviation usually means ?",
				new Option("Order of Significance", "Open Software", "Operating System", "Optical Sensor"), "N"));
		questions.add(new QuestionAccess(3, "In which decade with the first transatlantic radio broadcast occur?",
				new Option("1850s", "1860s", "1870s", "1900s"), "N"));
		questions.add(new QuestionAccess(4, "Which is a type of Electrically-Erasable Programmable Read-Only Memory?",
				new Option("Flash", "Flange", "Fury", "FRAM"), "N"));
		questions.add(new QuestionAccess(5, "The purpose of choke in tube light is ?",
				new Option("To decrease the current", "To increase the current", "To decrease the voltage momentarily",
						"To increase the voltage momentarily"),
				"Y"));
		questions.add(new QuestionAccess(6, "'.MPG' extension refers usually to what kind of file?",
				new Option("WordPerfect Document file", "MS Office document", "Animation/movie file", "Image file"),
				"Y"));
		questions.add(new QuestionAccess(7,
				"Who is largely responsible for breaking the German Enigma codes, created a test that provided a foundation for artificial intelligence?",
				new Option("Alan Turing", "Jeff Bezos", "George Boole", "Charles Babbage"), "Y"));
		questions.add(new QuestionAccess(8, "Who developed Yahoo?", new Option("Dennis Ritchie & Ken Thompson",
				"David Filo & Jerry Yang", "Vint Cerf & Robert Kahn", "Steve Case & Jeff Bezos"), "N"));
		questions.add(new QuestionAccess(9,
				"Made from a variety of materials, such as carbon, which inhibits the flow of current...?",
				new Option("Choke", "Inductor", "Resistor", "Capacitor"), "N"));
		questions.add(
				new QuestionAccess(10, "The most common format for a home video recorder is VHS. VHS stands for...?",
						new Option("Video Home System", "Very high speed", "Video horizontal standard",
								"Voltage house standard"),
						"N"));
		Mockito.when(questionService.findRandomQuestions()).thenReturn(questions);
		mockMvc.perform(get("/question/findRandomQuestion")).andExpect(status().isOk());
	}
}
