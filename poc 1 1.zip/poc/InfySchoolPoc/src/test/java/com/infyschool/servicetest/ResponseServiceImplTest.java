package com.infyschool.servicetest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.infyschool.entity.Answer;
import com.infyschool.entity.MyResponses;
import com.infyschool.entity.Option;
import com.infyschool.entity.Question;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Responses;
import com.infyschool.entity.Student;
import com.infyschool.exception.ServiceException;
import com.infyschool.repository.MyResponseRepo;
import com.infyschool.repository.QuestionRepository;
import com.infyschool.repository.ResponseRepository;
import com.infyschool.repository.StudentRepository;
import com.infyschool.service.ResponseService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ResponseServiceImplTest {
	@MockBean
	public ResponseService responseService;

	@MockBean
	public ResponseRepository responseRepo;

	@MockBean
	public StudentRepository repo;

	@MockBean
	public QuestionRepository questionRepo;

	@MockBean
	public MyResponseRepo myResponseRepo;

	@Test
	public void testSaveAnswers() throws ServiceException {

		Responses response = new Responses();
		List<Answer> answer = new ArrayList<>();
		answer.add(0, new Answer(1, "a"));
		answer.add(1, new Answer(2, "b"));
		answer.add(2, new Answer(3, "c"));
		answer.add(3, new Answer(4, "d"));
		answer.add(4, new Answer(5, "a"));
		answer.add(5, new Answer(6, "a"));
		answer.add(6, new Answer(7, "b"));
		answer.add(7, new Answer(8, "c"));
		answer.add(8, new Answer(9, "d"));
		answer.add(9, new Answer(10, "a"));
//		response.setQ_id(1);
		response.setStudent_id(1l);
		response.setAnswer(answer);
		response.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response.setCurrentIqScore(57);

		Student student = new Student();
		student.setIqScore(69);
		response.setStudent(student);

		Student studentdemo = new Student();
		studentdemo.setStudentId(1l);
		studentdemo.setIqScore(59);
		studentdemo.setNoOfAttempts(0);
		Optional<Student> studentdb = Optional.of(studentdemo);
		Mockito.when(repo.findById(1l)).thenReturn(studentdb);

		Student sdb = studentdb.get();

		Responses res = new Responses();
		res.setQ_id(1);
		res.setStudent(sdb);
		res.setStudent_id(sdb.getStudentId());
		res.setAnswer(response.getAnswer());
		res.setTime_of_attempt(response.getTime_of_attempt());
		res.setCurrentIqScore(student.getIqScore());

		Mockito.when(responseRepo.save(res)).thenReturn(res);
//		Responses a = responseService.saveAnswers(response, 1l);
//		Assertions.assertEquals(a, response);
		Responses rep = responseService.saveAnswers(response, 1l);
		assertNotNull(rep);
	}

	@Test
	public void testReturnAnswer() throws ServiceException {
		QuestionList questionList = new QuestionList();
		List<Integer> questionIds = new ArrayList<>();

		questionIds.add(0, 1);
		questionIds.add(1, 9);
		questionIds.add(2, 8);
		questionIds.add(3, 6);
		questionIds.add(4, 7);
		questionIds.add(5, 12);
		questionIds.add(6, 4);
		questionIds.add(7, 2);
		questionIds.add(8, 5);
		questionIds.add(9, 13);

		questionList.setQuestionId(questionIds);

		List<Answer> answer = new ArrayList<>();
		answer.add(0, new Answer(1, "a"));
		answer.add(1, new Answer(2, "b"));
		answer.add(2, new Answer(3, "c"));
		answer.add(3, new Answer(4, "d"));
		answer.add(4, new Answer(5, "a"));
		answer.add(5, new Answer(6, "a"));
		answer.add(6, new Answer(7, "b"));
		answer.add(7, new Answer(8, "c"));
		answer.add(8, new Answer(9, "d"));
		answer.add(9, new Answer(10, "a"));

		List<Question> questions = new LinkedList<>();
		questions.add(new Question(1, "What is the name of NationalBird?",
				new Option("Ostrich", "Peacock", "HummingBird", "Cockoo"), "Y", "a"));
		questions.add(new Question(2, "'OS' computer abbreviation usually means ?",
				new Option("Order of Significance", "Open Software", "Operating System", "Optical Sensor"), "N", "b"));
		questions.add(new Question(3, "In which decade with the first transatlantic radio broadcast occur?",
				new Option("1850s", "1860s", "1870s", "1900s"), "N", "c"));
		questions.add(new Question(4, "Which is a type of Electrically-Erasable Programmable Read-Only Memory?",
				new Option("Flash", "Flange", "Fury", "FRAM"), "N", "d"));
		questions
				.add(new Question(5, "The purpose of choke in tube light is ?",
						new Option("To decrease the current", "To increase the current",
								"To decrease the voltage momentarily", "To increase the voltage momentarily"),
						"Y", "a"));
		questions.add(new Question(6, "'.MPG' extension refers usually to what kind of file?",
				new Option("WordPerfect Document file", "MS Office document", "Animation/movie file", "Image file"),
				"Y", "b"));
		questions.add(new Question(7,
				"Who is largely responsible for breaking the German Enigma codes, created a test that provided a foundation for artificial intelligence?",
				new Option("Alan Turing", "Jeff Bezos", "George Boole", "Charles Babbage"), "Y", "c"));
		questions.add(new Question(8, "Who developed Yahoo?", new Option("Dennis Ritchie & Ken Thompson",
				"David Filo & Jerry Yang", "Vint Cerf & Robert Kahn", "Steve Case & Jeff Bezos"), "N", "d"));
		questions.add(new Question(9,
				"Made from a variety of materials, such as carbon, which inhibits the flow of current...?",
				new Option("Choke", "Inductor", "Resistor", "Capacitor"), "N", "d"));
		questions.add(new Question(10, "The most common format for a home video recorder is VHS. VHS stands for...?",
				new Option("Video Home System", "Very high speed", "Video horizontal standard",
						"Voltage house standard"),
				"N", "d"));

//		List<Question> question = questionRepo.findAllById(questionIds);
//		Mockito.when(questionRepo.findAllById(questionIds)).thenReturn(questions);
//		Assertions.assertEquals(responseService.returnAnswer(questionList), answer);
		
		Mockito.when(questionRepo.findAllById(Mockito.anyIterable())).thenReturn(questions);

		List<Answer> answer1=responseService.returnAnswer(questionList);

		assertNotNull(answer1);
	}

	@Test
	public void testMyResponse() {

		List<MyResponses> myrespo = new ArrayList<>();
		MyResponses response1 = new MyResponses();
		response1.setQ_id(1);
		response1.setStudent_id(1l);
		List<Answer> answer1 = new ArrayList<>();
		answer1.add(0, new Answer(1, "a"));
		answer1.add(1, new Answer(2, "b"));
		answer1.add(2, new Answer(3, "c"));
		answer1.add(3, new Answer(4, "d"));
		answer1.add(4, new Answer(5, "a"));
		answer1.add(5, new Answer(6, "a"));
		answer1.add(6, new Answer(7, "b"));
		answer1.add(7, new Answer(8, "c"));
		answer1.add(8, new Answer(9, "d"));
		answer1.add(9, new Answer(10, "a"));
		response1.setAnswer(answer1);
		response1.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response1.setCurrentIqScore(57);

		MyResponses response2 = new MyResponses();
		response2.setQ_id(2);
		response2.setStudent_id(1l);
		List<Answer> answer2 = new ArrayList<>();
		answer2.add(0, new Answer(1, "a"));
		answer2.add(1, new Answer(2, "b"));
		answer2.add(2, new Answer(3, "c"));
		answer2.add(3, new Answer(4, "d"));
		answer2.add(4, new Answer(5, "a"));
		answer2.add(5, new Answer(6, "a"));
		answer2.add(6, new Answer(7, "b"));
		answer2.add(7, new Answer(8, "c"));
		answer2.add(8, new Answer(9, "d"));
		answer2.add(9, new Answer(10, "a"));
		response2.setAnswer(answer2);
		response2.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response2.setCurrentIqScore(52);

		myrespo.add(0, response1);
		myrespo.add(1, response2);

//		Mockito.when(myResponseRepo.findMyResponse(1l)).thenReturn(myrespo);
//		Assertions.assertEquals(responseService.myResponse(1l), myrespo);
		Mockito.when(myResponseRepo.findMyResponse(Mockito.anyLong())).thenReturn(myrespo);
		List<MyResponses> mrespo = responseService.myResponse(3l);
		assertNotNull(mrespo);

	}

}
