package com.infyschool.exceptiontest;

public class ExceptionTest {
	
	
}
