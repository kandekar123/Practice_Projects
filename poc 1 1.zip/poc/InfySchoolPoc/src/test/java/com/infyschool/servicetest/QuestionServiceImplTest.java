package com.infyschool.servicetest;

import java.util.LinkedHashSet;
import java.util.Set;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.infyschool.entity.QuestionAccess;
import com.infyschool.repository.QuestionAccessRepository;
import com.infyschool.service.QuestionAccessService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QuestionServiceImplTest {

	@MockBean
	public QuestionAccessService questionService;

	@MockBean
	public QuestionAccessRepository questionRepo;

	@Test
	public void testFindRandomQuestions() {
		Set<QuestionAccess> questions = new LinkedHashSet<>();
		questions = questionRepo.findRandomQuestions();
		Mockito.when(questionRepo.findRandomQuestions()).thenReturn(questions);
		Assertions.assertEquals(questionService.findRandomQuestions(), questions);
	}
}
