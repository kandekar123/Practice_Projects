package com.infyschool.controllertest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infyschool.controller.ResponseController;
import com.infyschool.entity.Answer;
import com.infyschool.entity.MyResponses;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Responses;
import com.infyschool.entity.Student;
import com.infyschool.service.ResponseService;


@RunWith(SpringRunner.class)
@WebMvcTest(value = ResponseController.class)
public class ResponseControllerTest {
	@Autowired
	public MockMvc mockMvc;

	@MockBean
	public ResponseService responseService;

	@MockBean
	public UserDetailsService userDetails;



	@Mock
	ResponseService rserv;

	@Test
	public void testAddAnswers() throws JsonProcessingException, Exception {
		Responses response = new Responses();
		List<Answer> answer = new ArrayList<>();
		answer.add(0, new Answer(1, "a"));
		answer.add(1, new Answer(2, "b"));
		answer.add(2, new Answer(3, "c"));
		answer.add(3, new Answer(4, "d"));
		answer.add(4, new Answer(5, "a"));
		answer.add(5, new Answer(6, "a"));
		answer.add(6, new Answer(7, "b"));
		answer.add(7, new Answer(8, "c"));
		answer.add(8, new Answer(9, "d"));
		answer.add(9, new Answer(10, "a"));
		response.setAnswer(answer);
		response.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response.setCurrentIqScore(57);
		Student student = new Student();
		student.setIqScore(69);
		response.setStudent(student);

		Mockito.when(responseService.saveAnswers(response, 100l)).thenReturn(response);
		mockMvc.perform(post("/response/answer?id=1").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(response))).andExpect(status().isOk());

	}

	@Test
	public void testReturnAnswers() throws Exception {
		QuestionList questionList = new QuestionList();
		List<Integer> questionIds = new ArrayList<>();

		questionIds.add(0, 1);
		questionIds.add(1, 9);
		questionIds.add(2, 8);
		questionIds.add(3, 6);
		questionIds.add(4, 7);
		questionIds.add(5, 12);
		questionIds.add(6, 4);
		questionIds.add(7, 2);
		questionIds.add(8, 5);
		questionIds.add(9, 13);

		questionList.setQuestionId(questionIds);

		List<Answer> answer = new ArrayList<>();
		answer.add(0, new Answer(1, "a"));
		answer.add(1, new Answer(2, "b"));
		answer.add(2, new Answer(3, "c"));
		answer.add(3, new Answer(4, "d"));
		answer.add(4, new Answer(5, "a"));
		answer.add(5, new Answer(6, "a"));
		answer.add(6, new Answer(7, "b"));
		answer.add(7, new Answer(8, "c"));
		answer.add(8, new Answer(9, "d"));
		answer.add(9, new Answer(10, "a"));

		Mockito.when(responseService.returnAnswer(questionList)).thenReturn(answer);

		mockMvc.perform(post("/response/returnanswer").contentType(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(questionList))).andExpect(status().isOk());
	}

	@Test
	public void testMyResponses() throws Exception {
		List<MyResponses> myrespo = new ArrayList<>();

		MyResponses response1 = new MyResponses();
		response1.setQ_id(1);
		response1.setStudent_id(100l);
		List<Answer> answer1 = new ArrayList<>();
		answer1.add(0, new Answer(1, "a"));
		answer1.add(1, new Answer(2, "b"));
		answer1.add(2, new Answer(3, "c"));
		answer1.add(3, new Answer(4, "d"));
		answer1.add(4, new Answer(5, "a"));
		answer1.add(5, new Answer(6, "a"));
		answer1.add(6, new Answer(7, "b"));
		answer1.add(7, new Answer(8, "c"));
		answer1.add(8, new Answer(9, "d"));
		answer1.add(9, new Answer(10, "a"));
		response1.setAnswer(answer1);
		response1.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response1.setCurrentIqScore(57);

		MyResponses response2 = new MyResponses();
		response2.setQ_id(2);
		response2.setStudent_id(100l);
		List<Answer> answer2 = new ArrayList<>();
		answer2.add(0, new Answer(1, "a"));
		answer2.add(1, new Answer(2, "b"));
		answer2.add(2, new Answer(3, "c"));
		answer2.add(3, new Answer(4, "d"));
		answer2.add(4, new Answer(5, "a"));
		answer2.add(5, new Answer(6, "a"));
		answer2.add(6, new Answer(7, "b"));
		answer2.add(7, new Answer(8, "c"));
		answer2.add(8, new Answer(9, "d"));
		answer2.add(9, new Answer(10, "a"));
		response2.setAnswer(answer2);
		response2.setTime_of_attempt(java.sql.Time.valueOf(LocalTime.now()));
		response2.setCurrentIqScore(52);

		myrespo.add(0, response1);
		myrespo.add(1, response2);

		Mockito.when(responseService.myResponse(100l)).thenReturn(myrespo);

		mockMvc.perform(get("/response/myresponse?id=1")).andExpect(status().isOk());

	}
}
