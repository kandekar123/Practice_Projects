package com.infyschool.servicetest;



import static org.junit.jupiter.api.Assertions.assertNotNull;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit4.SpringRunner;
import com.infyschool.entity.English;
import com.infyschool.entity.Father;
import com.infyschool.entity.Grade;
import com.infyschool.entity.Login;
import com.infyschool.entity.Malayalam;
import com.infyschool.entity.Mathematics;
import com.infyschool.entity.Mother;
import com.infyschool.entity.MyStudentData;
import com.infyschool.entity.Overallgrade;
import com.infyschool.entity.Science;
import com.infyschool.entity.Siblings;
import com.infyschool.entity.Socialscience;
import com.infyschool.entity.Student;
import com.infyschool.entity.StudentData;
import com.infyschool.exception.ServiceException;
import com.infyschool.repository.StudentRepository;
import com.infyschool.repository.loginRepository;
import com.infyschool.service.StudentService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentServiceImplTest {
	@Autowired
	public StudentService studentService;

	@MockBean
	public StudentRepository studentRepo;

	@MockBean
	public loginRepository loginRepo;
	
	@MockBean
	public Login loginEntity;

	@Test
	public void testGetAllStudentByYear() throws ServiceException {
		
		Student student = new Student();
		student.setStudentId(1l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2017);
		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);

		student.setStudentData(studentData);
		
		List<Student> slist= new ArrayList<>();
		slist.add(student);
		Pageable p = PageRequest.of(1, 2);
		Page<Student> studentlist = new PageImpl<>(slist);
		Mockito.when(studentRepo.findByAdmissionYear(2017, p)).thenReturn(studentlist);
		Assertions.assertEquals(studentService.getAllStudentbyYear(2017, 1, 2), studentlist);
	}

	@Test
	public void testGetAllStudentById() throws ServiceException {

		Student student = new Student();
		student.setStudentId(1l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2017);
		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);

		student.setStudentData(studentData);

		Mockito.when(studentRepo.findBystudentId(1l)).thenReturn(student);
		Assertions.assertEquals(studentService.getAllStudentbyId(1l), student);
	}

	@Test
	public void testUpdateStudent() throws ServiceException {

		Student student = new Student();
		student.setStudentId(1l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2007);
		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);

		student.setStudentData(studentData);

		Mockito.when(studentRepo.save(student)).thenReturn(student);
		Mockito.when(studentRepo.findBystudentId(1)).thenReturn(student);
		Assertions.assertEquals(studentService.updateStudent(1l, student), student);
	}

//	@Test
//	public void testRegister() throws ServiceException {
//
//		Student student = new Student();
//		student.setStudentName("Josutty");
//		student.setAdmissionYear(2007);
//		
//		Long register =studentService.register(loginEntity);
//		
//		Login login = new Login();
//		login.setLoginid(2l);
//		login.setUsername("Josutty");
//		login.setPassword("Josutty@1998");
//		login.setDob(LocalDate.parse("2019-03-29"));
//		login.setStudent(student);
//		
//		Mockito.when(loginRepo.existsLoginByUsername(login.getUsername())).thenReturn(false);
//		Mockito.when(loginRepo.save(login)).thenReturn(login);
//		Mockito.when(studentRepo.save(student)).thenReturn(student);
//		Assertions.assertEquals(studentService.register(login), 2l);
//	}
	
	
	@Test

	void testRegister() throws ServiceException {
	Login log = new Login();
	log.setUsername("hinj");
	log.setLoginid(4l);
	log.setPassword("Ance");
	log.setDob(LocalDate.parse("2019-03-29"));
	Student stud=new Student();
	stud.setStudentName("Ayush");
	stud.setStudentId(3l);
	log.setStudent(stud);

	Mockito.when(loginRepo.save(Mockito.any())).thenReturn(log);

	Student stu= new Student();
	stu.setStudentName("Ayush");
	stu.setStudentId(log.getLoginid());
	stu.setIqScore(0);
	stu.setNoOfAttempts(2);

	Mockito.when(studentRepo.save(Mockito.any())).thenReturn(stu);
	Long register=studentService.register(log);

	assertNotNull(register);
	}
	
	
	
	
	@Test
	public void testFullData() {

		Student student = new Student();
		student.setStudentId(1l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2007);

		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);
		student.setStudentData(studentData);

		MyStudentData myStudentData = new MyStudentData();
		myStudentData.setStudentData(studentData);
		
		Optional<Student> studentdb = Optional.of(student);
		Mockito.when(studentRepo.findById(1l)).thenReturn(studentdb);
		Mockito.when(studentRepo.save(student)).thenReturn(student);
		Assertions.assertEquals(studentService.FullData(1l, myStudentData), student);
	}

	@Test
	public void testLogin() throws ServiceException {
		Student student = new Student();
		student.setStudentName("Josutty");
		student.setAdmissionYear(2007);
		Login login = new Login();
		login.setUsername("Josutty");
		login.setPassword("Josutty@1998");
		login.setDob(LocalDate.parse("2019-03-29"));
		login.setStudent(student);
		Mockito.when(loginRepo.findByusername(login.getUsername())).thenReturn(login);
		Assertions.assertEquals(studentService.loginService(login.getUsername(), login.getPassword()), null);
	}
}
