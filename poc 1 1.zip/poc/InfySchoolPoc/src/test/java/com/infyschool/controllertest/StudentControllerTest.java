package com.infyschool.controllertest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infyschool.controller.StudentController;
import com.infyschool.entity.English;
import com.infyschool.entity.Father;
import com.infyschool.entity.Grade;
import com.infyschool.entity.Loggertab;
import com.infyschool.entity.Login;
import com.infyschool.entity.Malayalam;
import com.infyschool.entity.Mathematics;
import com.infyschool.entity.Mother;
import com.infyschool.entity.MyStudentData;
import com.infyschool.entity.Overallgrade;
import com.infyschool.entity.Science;
import com.infyschool.entity.Siblings;
import com.infyschool.entity.Socialscience;
import com.infyschool.entity.Student;
import com.infyschool.entity.StudentData;
import com.infyschool.repository.StudentRepository;
import com.infyschool.repository.loginRepository;
import com.infyschool.service.LogService;
import com.infyschool.service.StudentService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = StudentController.class)

public class StudentControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private Loggertab logger;

	@MockBean
	private UserDetailsService userdetails;

	@MockBean
	private LogService log;

	@MockBean
	private StudentService service;

	@MockBean
	private StudentRepository repo;

	@MockBean
	private loginRepository loginrepo;

	@Test
	public void testGetAllStudentByYear() throws Exception {
		Pageable p = PageRequest.of(1, 2);
		Page<Student> studentlist = repo.findByAdmissionYear(2017, p);
		Mockito.when(service.getAllStudentbyYear(2017, 1, 2)).thenReturn(studentlist);
		mockMvc.perform(get("/student/students/2017?page=1&size=2")).andExpect(status().isOk());

	}

	@Test
	public void testGetAllStudentbyId() throws Exception {
		Student student = new Student();
		student.setStudentId(100l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2007);
		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);

		student.setStudentData(studentData);

		Mockito.when(service.getAllStudentbyId(100l)).thenReturn(student);
		mockMvc.perform(get("/student/{studentId}", 100l)).andExpect(status().isOk());
	}

	@Test
	public void testUpdateStudent() throws JsonProcessingException, Exception {

		Student student = new Student();
		student.setStudentId(100l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2007);
		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);

		student.setStudentData(studentData);

		Mockito.when(service.updateStudent(100l, student)).thenReturn(student);
		mockMvc.perform(put("/student/{studentId}", 100l).contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(student))).andExpect(status().isOk());
	}

	@Test
	public void testRegisterstudentId() throws Exception {
		Student student = new Student();
		student.setStudentName("Josutty");
		student.setAdmissionYear(2007);
		Login login = new Login();
		login.setUsername("Josutty");
		login.setPassword("Josutty@1998");
		login.setDob(LocalDate.parse("2019-03-29"));
		login.setStudent(student);
		Mockito.when(service.register(login)).thenReturn(100l);
		mockMvc.perform(post("/student/register").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(login))).andExpect(status().isCreated());
	}

	@Test
	public void testFulldata() throws JsonProcessingException, Exception {

		Student student = new Student();
		student.setStudentId(100l);
		student.setStudentName("Ance");
		student.setAdmissionYear(2007);

		StudentData studentData = new StudentData();
		Father father = new Father();
		father.setDob("12-03-1998");
		father.setJob("Farmer");
		father.setName("Poulose");
		studentData.setFather(father);
		Mother mother = new Mother();
		mother.setDob("12-03-1998");
		mother.setJob("Farmer");
		mother.setName("Poulose");
		studentData.setMother(mother);
		List<Siblings> siblings = new ArrayList<>();
		siblings.add(0, new Siblings("Brother", "Ance", "IT"));
		siblings.add(1, new Siblings("Sister", "Ancy", "Nurse"));
		studentData.setSiblings(siblings);
		List<Grade> grade = new ArrayList<>();
		grade.add(0, new Grade(new Mathematics(67, 23, 18), new Science(98, 23, 21), new Socialscience(89, 24, 12),
				new English(90, 21, 15), new Malayalam(89, 16, 17)));
		grade.add(1, new Grade(new Mathematics(65, 22, 15), new Science(94, 25, 22), new Socialscience(85, 23, 11),
				new English(97, 23, 17), new Malayalam(87, 14, 10)));
		studentData.setGrade(grade);

		Overallgrade overallgrade = new Overallgrade();
		overallgrade.setOverallgrade("B+");
		studentData.setOverallgrade(overallgrade);
		student.setStudentData(studentData);

		MyStudentData myStudentData = new MyStudentData();
		myStudentData.setStudentData(studentData);

		Mockito.when(service.FullData(100l, myStudentData)).thenReturn(student);
		mockMvc.perform(put("/student/fulldetails?studentId=1").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(myStudentData))).andExpect(status().isOk());
	}

	@Test
	public void testLogin() throws JsonProcessingException, Exception {

		Login login = new Login();
		login.setUsername("Josutty");
		login.setPassword("Josutty@1998");

		Mockito.when(service.loginService("Josutty", "Josutty@1998")).thenReturn("101l");
		mockMvc.perform(post("/student/login").contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(login))).andExpect(status().isOk());
	}

}
