package com.infyschool.servicetest;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit4.SpringRunner;

import com.infyschool.entity.Login;
import com.infyschool.entity.LoginUserDetails;
import com.infyschool.entity.Student;
import com.infyschool.repository.loginRepository;
import com.infyschool.service.LoginDetailsServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LoginDetailsServiceImplTest {
	@MockBean
	public LoginDetailsServiceImpl loginDetails;

	@MockBean
	public loginRepository loginRepo;

	@MockBean
	public LoginUserDetails loginUserDetails;

	@Test
	public void testLoadUserByUsername() {

		Student student = new Student();
		student.setStudentName("Josutty");
		student.setAdmissionYear(2007);
		Login login = new Login();
		login.setUsername("Josutty");
		login.setPassword("Josutty@1998");
		login.setDob(LocalDate.parse("2019-03-29"));
		login.setStudent(student);
		String s = "Josuuty";
		Mockito.when(loginRepo.findByusername(Mockito.any())).thenReturn(login);
		UserDetails userdetails = loginDetails.loadUserByUsername(s);
		Assertions.assertEquals(userdetails, loginDetails.loadUserByUsername(s));
	}
}
