package com.infy.school.entitytest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.jupiter.MockitoExtension;
import com.infyschool.dto.EnglishDTO;
import com.infyschool.dto.FatherDetailsDTO;
import com.infyschool.dto.GradeDetailsDTO;
import com.infyschool.dto.LoginDTO;
import com.infyschool.dto.MalayalamDTO;
import com.infyschool.dto.MathematicsDTO;
import com.infyschool.dto.MotherDetailsDTO;
import com.infyschool.dto.OptionDTO;
import com.infyschool.dto.OverAllGradeDTO;
import com.infyschool.dto.QuestionDTO;
import com.infyschool.dto.ResponseDTOO;
import com.infyschool.dto.ScienceDTO;
import com.infyschool.dto.SiblingsDetailsDTO;
import com.infyschool.dto.SocialScienceDTO;
import com.infyschool.dto.StudentDataDTO;
import com.infyschool.entity.Answer;
import com.infyschool.entity.English;
import com.infyschool.entity.Father;
import com.infyschool.entity.Grade;
import com.infyschool.entity.Loggertab;
import com.infyschool.entity.Malayalam;
import com.infyschool.entity.Mathematics;
import com.infyschool.entity.Mother;
import com.infyschool.entity.MyStudentData;
import com.infyschool.entity.Option;
import com.infyschool.entity.Overallgrade;
import com.infyschool.entity.Question;
import com.infyschool.entity.QuestionAccess;
import com.infyschool.entity.QuestionList;
import com.infyschool.entity.Science;
import com.infyschool.entity.Siblings;
import com.infyschool.entity.Socialscience;
import com.infyschool.entity.Student;
import com.infyschool.entity.StudentData;

@ExtendWith(MockitoExtension.class)
public class EntityTester {

	@Test
	public void testAllEntity() {
		BeanTester beantester = new BeanTester();
		beantester.testBean(Answer.class);
		beantester.testBean(English.class);
		beantester.testBean(Father.class);
		beantester.testBean(Grade.class);
		beantester.testBean(Loggertab.class);
		beantester.testBean(Malayalam.class);
		beantester.testBean(Mathematics.class);
		beantester.testBean(Mother.class);
		beantester.testBean(MyStudentData.class);
		beantester.testBean(Option.class);
		beantester.testBean(Overallgrade.class);
		beantester.testBean(Question.class);
		beantester.testBean(QuestionAccess.class);
		beantester.testBean(QuestionList.class);
		beantester.testBean(Science.class);
		beantester.testBean(Siblings.class);
		beantester.testBean(Socialscience.class);
		beantester.testBean(Student.class);
		beantester.testBean(StudentData.class);
		beantester.testBean(EnglishDTO.class);
		beantester.testBean(FatherDetailsDTO.class);
		beantester.testBean(GradeDetailsDTO.class);
		beantester.testBean(LoginDTO.class);
		beantester.testBean(MalayalamDTO.class);
		beantester.testBean(MathematicsDTO.class);
		beantester.testBean(MotherDetailsDTO.class);
		beantester.testBean(OptionDTO.class);
		beantester.testBean(OverAllGradeDTO.class);
		beantester.testBean(QuestionDTO.class);
		beantester.testBean(ResponseDTOO.class);
		beantester.testBean(ScienceDTO.class);
		beantester.testBean(SiblingsDetailsDTO.class);
		beantester.testBean(SocialScienceDTO.class);
		beantester.testBean(StudentDataDTO.class);

	}
}
